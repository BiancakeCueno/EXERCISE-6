<?php
 include_once 'header.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="team.css" />
    <title>GROUP 1_BSIT3G</title>
   
</head>


<body> 
 

   <div class="sticky"> 
    <h1 style="color: f36773;">
        MEET OUR TEAM
    </h1>
   </div>
<div class="row" > 
<div class="column">
<div class ="card"> 
   <img src="images/christa.jpg">
   <pre>    NAME: 
    CUENO, Christa Bianca
    AGE: 
    24 years old
    STUDENT NUMBER: 
    22143701
    INSTITUTIONAL EMAIL: 
    cuenochristabianca_bsit@plmun.edu.ph
    HOBBY: 
    Sleeping
   </pre>
</div>  
</div>

<div class="column">
<div class ="card"> 
   <img src="images/gwen.jpg">
   <pre>    NAME: 
    OTIC, Gwen Hillary 
    AGE: 
    20 years old
    STUDENT NUMBER: 
    22142945
    INSTITUTIONAL EMAIL: 
    oticgwenhillary_bsit@plmun.edu.ph
    HOBBY: 
    Eating
   </pre>
</div>
</div>

<div class="column">
<div class ="card"> 
   <img src="images/angge.jpg">
   <pre>    NAME: 
    PEREZ, Angeline  
    AGE: 
    20 years old
    STUDENT NUMBER: 
    22143289
    INSTITUTIONAL EMAIL: 
    perezangeline_bsit@plmun.edu.ph
    HOBBY: 
    Play Games
   </pre>
</div>
</div>

<div class="column">
<div class ="card"> 
   <img src="images/judel.jpg">
   <pre>    NAME: 
    COLICO, Judel  
    AGE: 
    20 years old
    STUDENT NUMBER: 
    22143731
    INSTITUTIONAL EMAIL: 
    colicojudel_bsit@plmun.edu.ph
    HOBBY: 
    Making Music
   </pre>
</div>
</div>

<div class="column">
<div class ="card"> 
   <img src="images/alef.jpg">
   <pre>    NAME: 
    LORESCA, Alef Justin  
    AGE: 
    20 years old
    STUDENT NUMBER: 
    22143394
    INSTITUTIONAL EMAIL: 
    lorescaalefjustin_bsit@plmun.edu.ph
    HOBBY: 
    Going to Gym
   </pre>
</div>
</div>
</div>


<div>
   <h1 id="greeting"></h1>
   <h1 id="clock"></h1>
 </div>
 

</body>

<?php
  include_once 'footer.php';
?>

</html>